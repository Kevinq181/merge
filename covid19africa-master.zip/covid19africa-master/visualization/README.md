Put plots and visuasation here.
