This folder contains basic stats and data not directly related to COVID-19 but is useful for analysis such as: 

* hospital beds
* number of doctors
* population stats (such as population density, land area, migrants, fertility rate, median age, urban population etc.), and 
* demographics (such as population breakdown by gender, life expectancy, etc.)
