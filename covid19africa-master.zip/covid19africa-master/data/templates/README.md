## Submitting
When ready to submit, make sure you name the file

line-list-**country**.csv

Change **country** to the name of the country. 

**Note:** You can only submit csv file. We made it easy for some to start with an xlsx file. 

## Other formats
You can also get the template on [Google Sheets](https://docs.google.com/spreadsheets/d/1qyIVKiFFH712l5SYYo2LKsgMabjeX-Z8WSv_WBLUAao/edit?usp=sharing)
